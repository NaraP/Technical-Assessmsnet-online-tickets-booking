﻿using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;
using System.Threading;
using ApiApplication.Models;
using ApiApplication.IServices;

namespace ApiApplication.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ShowtimeController : ControllerBase
    {
        private readonly IShowtimeService _showtimeService;
        private readonly IApiServiceClientGrpc _apiServiceClientGrpc;

        public ShowtimeController(IShowtimeService showtimeService, IApiServiceClientGrpc apiServiceClientGrpc)
        {
            _showtimeService = showtimeService;
            _apiServiceClientGrpc = apiServiceClientGrpc;
        }

        [HttpPost]
        public async Task<IActionResult> CreateShowtime([FromBody] ShowtimeRequest showtimeRequest, CancellationToken cancellationToken)
        {
            if (showtimeRequest is null)
                return BadRequest("Showtime request cannot be null.");

            if (showtimeRequest.Movie is null)
                return BadRequest("Movie details are required.");

            var movies = await _apiServiceClientGrpc.GetAllAsync();

            if (movies.Shows.Count < 0)
            {
                return BadRequest("Movie details are not found in API response.");
            }

            var createdShowtime = await _showtimeService.CreateShowtime(showtimeRequest, movies, cancellationToken);

            return Ok(createdShowtime);
        }

        // Example method to retrieve showtime by ID
        [HttpGet("{id}")]
        public async Task<IActionResult> GetShowtime(int id, CancellationToken cancellationToken)
        {
            var showtime = await _showtimeService.GetWithMoviesByIdAsync(id, cancellationToken);
            if (showtime == null)
            {
                return NotFound();
            }
            return Ok(showtime);
        }
    }
}
