﻿using ApiApplication.Models;
using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;
using System.Threading;
using System;
using ApiApplication.IServices;

namespace ApiApplication.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ReservationController : ControllerBase
    {
        private readonly IReservationService _reservationService;
        public ReservationController(IReservationService reservationService)
        {
            _reservationService = reservationService;
        }

        [HttpPost("reserve")]
        public async Task<IActionResult> ReserveSeats([FromBody] ReserveSeatsRequest request, CancellationToken cancel)
        {
            try
            {
                var result = await _reservationService.ReserveSeatsAsync(request.ShowtimeId, request.SeatIds, cancel);
                return Ok(result);
            }
            catch (Exception ex)
            {
                return BadRequest(new { error = ex.Message });
            }
        }
        [HttpPost("tickets/{reservationId:guid}/confirm")]
        public async Task<IActionResult> ConfirmReservation(Guid reservationId, CancellationToken cancellationToken)
        {
            var result = await _reservationService.ConfirmReservationAsync(reservationId, cancellationToken);

            return result switch
            {
                TicketConfirmationResult.Success => Ok("Reservation confirmed."),
                TicketConfirmationResult.NotFound => NotFound("Reservation not found."),
                TicketConfirmationResult.AlreadyPaid => BadRequest("This reservation has already been confirmed."),
                TicketConfirmationResult.Expired => BadRequest("This reservation has expired."),
                TicketConfirmationResult.SeatsAlreadySold => Conflict("Some of the seats are already sold."),
                _ => StatusCode(500, "An unexpected error occurred.")
            };
        }
    }
}
