﻿using ApiApplication.IServices;
using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;

namespace ApiApplication.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class MoviesController : ControllerBase
    {
        private readonly IApiServiceClientGrpc _apiServiceClientGrpc;

        public MoviesController(IApiServiceClientGrpc apiServiceClientGrpc) 
        {
            _apiServiceClientGrpc = apiServiceClientGrpc;
        }

        [HttpGet]
        public async Task<IActionResult> GetMovies() 
        {
            var shows = await _apiServiceClientGrpc.GetAllAsync();

            return shows is null ? NotFound() : Ok(shows);
        }
    }
}
