﻿using ApiApplication.Database.Repositories.Abstractions;
using ApiApplication.Database.Repositories;
using ApiApplication.Services;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using ApiApplication.IServices;

namespace ApiApplication.Extensions
{
    public static class RegisterService
    {
        public static void ConfigureService(this IServiceCollection services, IConfiguration configuration)
        {
            // RegisterServices
            services.AddTransient<IShowtimesRepository, ShowtimesRepository>();
            services.AddTransient<ITicketsRepository, TicketsRepository>();
            services.AddTransient<IAuditoriumsRepository, AuditoriumsRepository>();
            services.AddTransient<IApiServiceClientGrpc, ApiServiceClientGrpc>();
            services.AddTransient<IShowtimeService, ShowtimeService>();
            services.AddScoped<IRedisCacheService, RedisCacheService>();
            services.AddScoped<IReservationService, ReservationService>();
            services.AddHttpClient();
            services.AddControllers();
            services.AddEndpointsApiExplorer();

            services.AddSingleton<IHttpContextAccessor, HttpContextAccessor>();
        }
    }
}
