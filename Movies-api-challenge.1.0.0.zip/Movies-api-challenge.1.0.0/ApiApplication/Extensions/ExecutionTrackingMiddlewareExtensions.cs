﻿using ApiApplication.Middleware;
using Microsoft.AspNetCore.Builder;

namespace ApiApplication.Extensions
{
    public static class ExecutionTrackingMiddlewareExtensions
    {
        public static IApplicationBuilder UseExecutionTracking(this IApplicationBuilder app)
        {
            return app.UseMiddleware<ExecutionTrackingMiddleware>();
        }
    }
}
