﻿namespace ApiApplication.Models
{
    public enum TicketConfirmationResult
    {
        Success,
        NotFound,
        AlreadyPaid,
        Expired,
        SeatsAlreadySold
    }
}
