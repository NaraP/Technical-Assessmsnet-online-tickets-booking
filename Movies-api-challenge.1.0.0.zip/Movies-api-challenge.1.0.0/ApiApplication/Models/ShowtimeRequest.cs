﻿using System.Collections.Generic;
using System;

namespace ApiApplication.Models
{
    public class ShowtimeRequest
    {
        public int Id { get; set; }
        public Movie Movie { get; set; }
        public DateTime SessionDate { get; set; }
        public int AuditoriumId { get; set; }
        public List<Ticket> Tickets { get; set; }
    }

    public class Movie
    {
        public int Id { get; set; }
        public string Title { get; set; }
        public string ImdbId { get; set; }
        public string Stars { get; set; }
        public DateTime ReleaseDate { get; set; }
        public List<string> Showtimes { get; set; }
    }

    public class Ticket
    {
        public Guid Id { get; set; }
        public int ShowtimeId { get; set; }
        public List<Seat> Seats { get; set; }
        public DateTime CreatedTime { get; set; }
        public bool Paid { get; set; }
        public string Showtime { get; set; }
    }

    public class Seat
    {
        public short Row { get; set; }
        public short SeatNumber { get; set; }
        public int AuditoriumId { get; set; }
        public Auditorium Auditorium { get; set; }
    }

    public class Auditorium
    {
        public int Id { get; set; }
        public List<string> Showtimes { get; set; }
        public List<string> Seats { get; set; }
    }

    public class Show
    {
        public string Id { get; set; }
        public string Rank { get; set; }
        public string Title { get; set; }
        public string FullTitle { get; set; }
        public string Year { get; set; }
        public string Image { get; set; }
        public string Crew { get; set; }
        public string ImDbRating { get; set; }
        public string ImDbRatingCount { get; set; }
    }

    public class ShowListResponse
    {
        public List<Show> Shows { get; set; }
    }
}
