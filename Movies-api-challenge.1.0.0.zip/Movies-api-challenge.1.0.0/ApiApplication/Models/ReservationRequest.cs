﻿using System.Collections.Generic;
using System;

namespace ApiApplication.Models
{
    public class ReservationRequest
    {
        public int AuditoriumId { get; set; }
        public int MovieId { get; set; }
        public List<SeatReservation> Seats { get; set; }
    }

    public class SeatReservation
    {
        public int Row { get; set; }
        public int SeatNumber { get; set; }
    }

    public class ReservationResponse
    {
        public Guid ReservationId { get; set; }
        public int NumberOfSeats { get; set; }
        public int AuditoriumId { get; set; }
        public int MovieId { get; set; }
        public DateTime ExpiryTime { get; set; }
    }

    public class ReservedSeat
    {
        public int Row { get; set; }
        public int SeatNumber { get; set; }
        public Guid ReservationId { get; set; }
        public DateTime ReservedAt { get; set; }
    }
}
