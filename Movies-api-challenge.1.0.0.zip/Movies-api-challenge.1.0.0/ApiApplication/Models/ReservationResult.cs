﻿using System;
using System.Collections.Generic;

namespace ApiApplication.Models
{
    public class ReservationResult
    {
        public Guid ReservationId { get; set; }
        public int SeatCount { get; set; }
        public string MovieTitle { get; set; }
        public int AuditoriumId { get; set; }
    }
    public class ReserveSeatsRequest
    {
        public int ShowtimeId { get; set; }
        public List<int> SeatIds { get; set; }
    }
}
