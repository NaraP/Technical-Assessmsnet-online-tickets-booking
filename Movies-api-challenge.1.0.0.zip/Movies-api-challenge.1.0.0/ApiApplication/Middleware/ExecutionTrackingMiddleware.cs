﻿using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using System;
using System.Diagnostics;
using System.Diagnostics.CodeAnalysis;
using System.Threading.Tasks;

namespace ApiApplication.Middleware
{
    [ExcludeFromCodeCoverage]
    public class ExecutionTrackingMiddleware
    {
        private readonly RequestDelegate _next;
        private readonly ILogger<ExecutionTrackingMiddleware> _logger;

        public ExecutionTrackingMiddleware(RequestDelegate next, ILogger<ExecutionTrackingMiddleware> logger)
        {
            _next = next ?? throw new ArgumentNullException(nameof(next));
            _logger = logger ?? throw new ArgumentNullException(nameof(logger));
        }

        public async Task InvokeAsync(HttpContext context)
        {
            // Start the timer
            var stopwatch = Stopwatch.StartNew();

            try
            {
                // Process the request
                await _next(context);

                // Log successful request details
                LogRequest(context, stopwatch, null);
            }
            catch (Exception ex)
            {
                // Log request with error
                LogRequest(context, stopwatch, ex);
                throw; // Re-throw to allow exception handling middleware to process
            }
        }

        private void LogRequest(HttpContext context, Stopwatch stopwatch, Exception? exception)
        {
            stopwatch.Stop();
            var method = context.Request.Method;
            var path = context.Request.Path;
            var statusCode = context.Response.StatusCode;
            var durationMs = stopwatch.ElapsedMilliseconds;
            var userId = context.User.Identity?.Name ?? "Anonymous";

            if (exception == null)
            {
                _logger.LogInformation(
                    "Request executed: {Method} {Path} by {UserId} with status {StatusCode} in {DurationMs}ms",
                    method, path, userId, statusCode, durationMs);
            }
            else
            {
                _logger.LogError(
                    exception,
                    "Request failed: {Method} {Path} by {UserId} with status {StatusCode} in {DurationMs}ms",
                    method, path, userId, statusCode, durationMs);
            }
        }
    }
}
