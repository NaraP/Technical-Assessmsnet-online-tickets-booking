﻿using ApiApplication.Models;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Threading;
using System;
using System.Linq;
using ApiApplication.Database.Repositories.Abstractions;
using ApiApplication.Database.Entities;
using Microsoft.Extensions.Logging;
using ApiApplication.IServices;

namespace ApiApplication.Services
{
    public class ReservationService : IReservationService
    {
        private readonly ITicketsRepository _ticketsRepository;
        private readonly IShowtimesRepository _showtimesRepository;
        private readonly IAuditoriumsRepository _auditoriumsRepository;
        private readonly ILogger<ReservationService> _logger;

        public ReservationService(
           ITicketsRepository ticketsRepository,
           IShowtimesRepository showtimesRepository,
           IAuditoriumsRepository auditoriumsRepository,
           ILogger<ReservationService> logger)
        {
            _ticketsRepository = ticketsRepository ?? throw new ArgumentNullException(nameof(ticketsRepository));
            _showtimesRepository = showtimesRepository ?? throw new ArgumentNullException(nameof(showtimesRepository));
            _auditoriumsRepository = auditoriumsRepository ?? throw new ArgumentNullException(nameof(auditoriumsRepository));
            _logger = logger ?? throw new ArgumentNullException(nameof(logger));
        }

        public async Task<ReservationResult> ReserveSeatsAsync(int showtimeId, IEnumerable<int> requestedSeatIds, CancellationToken cancellationToken)
        {
            try
            {
                if (requestedSeatIds == null || !requestedSeatIds.Any())
                {
                    _logger.LogWarning("ReserveSeatsAsync called with empty or null seat IDs for showtime {ShowtimeId}", showtimeId);
                    throw new ArgumentException("At least one seat must be requested.");
                }

                // Retrieve showtime data
                var showtime = await _showtimesRepository.GetWithTicketsByIdAsync(showtimeId, cancellationToken);
                if (showtime == null)
                {
                    _logger.LogWarning("Showtime {ShowtimeId} not found.", showtimeId);
                    throw new InvalidOperationException("Showtime not found.");
                }

                // Retrieve auditorium data
                var auditorium = await _auditoriumsRepository.GetAsync(showtime.AuditoriumId, cancellationToken);
                if (auditorium == null)
                {
                    _logger.LogWarning("Auditorium {AuditoriumId} not found for showtime {ShowtimeId}.", showtime.AuditoriumId, showtimeId);
                    throw new InvalidOperationException("Auditorium not found.");
                }

                // Validate requested seats
                var allSeats = auditorium.Seats;
                var selectedSeats = allSeats.Where(s => requestedSeatIds.Contains(s.SeatNumber)).ToList();

                if (selectedSeats.Count == requestedSeatIds.Count())
                {
                    _logger.LogWarning("Some requested seats do not exist for showtime {ShowtimeId}.", showtimeId);
                    throw new InvalidOperationException("Some requested seats do not exist.");
                }

                // Check the seats are contiguous
                if (!AreSeatsContiguous(selectedSeats))
                {
                    _logger.LogWarning("Requested seats are not contiguous for showtime {ShowtimeId}.", showtimeId);
                    throw new InvalidOperationException("Seats must be contiguous.");
                }

                // Check for reserved or sold seats
                var activeTickets = showtime.Tickets
                    .Where(t => !t.Paid && DateTime.UtcNow - t.CreatedTime < TimeSpan.FromMinutes(10))
                    .ToList();

                var reservedSeatIds = activeTickets
                    .SelectMany(t => t.Seats)
                    .Select(s => (int)s.SeatNumber)
                    .ToList();

                var soldSeatIds = showtime.Tickets
                    .Where(t => t.Paid)
                    .SelectMany(t => t.Seats)
                    .Select(s => (int)s.SeatNumber)
                    .ToList();

                if (requestedSeatIds.Any(id => reservedSeatIds.Contains(id)))
                {
                    _logger.LogWarning("Some seats are already reserved for showtime {ShowtimeId}.", showtimeId);
                    throw new InvalidOperationException("Some seats are already reserved.");
                }

                if (requestedSeatIds.Any(id => soldSeatIds.Contains(id)))
                {
                    _logger.LogWarning("Some seats are already sold for showtime {ShowtimeId}.", showtimeId);
                    throw new InvalidOperationException("Some seats are already sold.");
                }

                // Create ticket (reservation)
                var ticket = await _ticketsRepository.CreateAsync(showtime, selectedSeats, cancellationToken);

                _logger.LogInformation("Successfully reserved {SeatCount} seats for showtime {ShowtimeId}, reservation ID {ReservationId}.",
                    selectedSeats.Count, showtimeId, ticket.Id);

                return new ReservationResult
                {
                    ReservationId = ticket.Id,
                    SeatCount = selectedSeats.Count,
                    MovieTitle = showtime.Movie.Title,
                    AuditoriumId = auditorium.Id
                };
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error reserving seats for showtime {ShowtimeId}.", showtimeId);
                throw;
            }
        }

        private bool AreSeatsContiguous(List<SeatEntity> seats)
        {
            var ordered = seats.OrderBy(s => s.Row).ThenBy(s => s.SeatNumber).ToList();
            if (ordered.Count <= 1)
                return true;

            var firstSeat = ordered[0];
            for (int i = 1; i < ordered.Count; i++)
            {
                if (ordered[i].Row != firstSeat.Row || ordered[i].SeatNumber != ordered[i - 1].SeatNumber + 1)
                {
                    return false;
                }
            }
            return true;
        }

        public async Task<TicketConfirmationResult> ConfirmReservationAsync(Guid reservationId, CancellationToken cancellationToken)
        {
            try
            {
                var ticket = await _ticketsRepository.GetAsync(reservationId, cancellationToken);
                if (ticket == null)
                {
                    _logger.LogWarning("Reservation {ReservationId} not found.", reservationId);
                    return TicketConfirmationResult.NotFound;
                }

                if (ticket.Paid)
                {
                    _logger.LogWarning("Reservation {ReservationId} is already paid.", reservationId);
                    return TicketConfirmationResult.AlreadyPaid;
                }

                if (ticket.CreatedTime.AddMinutes(10) < DateTime.UtcNow)
                {
                    _logger.LogWarning("Reservation {ReservationId} has expired.", reservationId);
                    return TicketConfirmationResult.Expired;
                }

                var allTickets = await _ticketsRepository.GetEnrichedAsync(ticket.ShowtimeId, cancellationToken);
                var seatAlreadySold = allTickets
                    .Where(t => t.Paid && t.Id != ticket.Id)
                    .SelectMany(t => t.Seats)
                    .Any(paidSeat => ticket.Seats.Any(reservedSeat =>
                        reservedSeat.Row == paidSeat.Row &&
                        reservedSeat.SeatNumber == paidSeat.SeatNumber &&
                        reservedSeat.AuditoriumId == paidSeat.AuditoriumId));

                if (seatAlreadySold)
                {
                    _logger.LogWarning("Some seats in reservation {ReservationId} are already sold.", reservationId);
                    return TicketConfirmationResult.SeatsAlreadySold;
                }

                await _ticketsRepository.ConfirmPaymentAsync(ticket, cancellationToken);
                _logger.LogInformation("Successfully confirmed reservation {ReservationId}.", reservationId);
                return TicketConfirmationResult.Success;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error confirming reservation {ReservationId}.", reservationId);
                throw;
            }
        }
    }
}