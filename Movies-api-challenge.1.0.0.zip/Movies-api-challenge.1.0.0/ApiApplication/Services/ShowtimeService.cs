﻿using ApiApplication.Database.Entities;
using ApiApplication.Database.Repositories.Abstractions;
using ApiApplication.Models;
using System.Linq;
using System;
using System.Collections.Generic;
using System.Linq.Expressions;
using System.Threading;
using System.Threading.Tasks;
using System.Text.Json;
using ProtoDefinitions;
using ApiApplication.IServices;

namespace ApiApplication.Services
{
    public class ShowtimeService : IShowtimeService
    {
        private readonly IShowtimesRepository _showtimeRepository;
        private readonly IApiServiceClientGrpc _apiServiceClientGrpc; 

        public ShowtimeService(IShowtimesRepository showtimeRepository, IApiServiceClientGrpc apiServiceClientGrpc) 
        {
            _showtimeRepository = showtimeRepository;
            _apiServiceClientGrpc = apiServiceClientGrpc;
        }

        public async Task<ShowtimeEntity> CreateShowtime(ShowtimeRequest showtimeRequest, ShowListResponse movies, CancellationToken cancel)
        {
            ShowtimeEntity showtimeEntityObj = new ShowtimeEntity();

            try
            {
                var showtimeEntity = new ShowtimeEntity
                {
                    Id = showtimeRequest.Id,
                    SessionDate = showtimeRequest.SessionDate,
                    AuditoriumId = showtimeRequest.AuditoriumId,

                    Movie = new MovieEntity
                    {
                        Id = showtimeRequest.Movie.Id,
                        Title = movies.Shows[0].FullTitle ?? movies.Shows[0].Title,
                        ImdbId = movies.Shows[0].Id,
                        Stars = movies.Shows[0].ImDbRating,
                        ReleaseDate = showtimeRequest.Movie.ReleaseDate
                    },
                    Tickets = showtimeRequest.Tickets?.Select(ticket => new TicketEntity
                    {
                        Id = ticket.Id = Guid.NewGuid(),
                        ShowtimeId = ticket.ShowtimeId,
                        CreatedTime = ticket.CreatedTime,
                        Paid = ticket.Paid,
                        Seats = ticket.Seats?.Select(seat => new SeatEntity
                        {
                            Row = seat.Row,
                            SeatNumber = seat.SeatNumber,
                            AuditoriumId = seat.AuditoriumId
                        }).ToList()
                    }).ToList() ?? new List<TicketEntity>()
                };

                showtimeEntityObj = await _showtimeRepository.CreateShowtime(showtimeEntity, cancel);
            }
            catch (Exception ex) 
            { 
            }
            return showtimeEntityObj;
        }

        public async Task<IEnumerable<ShowtimeEntity>> GetAllAsync(Expression<Func<ShowtimeEntity, bool>> filter, CancellationToken cancel)
        {
            return await _showtimeRepository.GetAllAsync(filter, cancel);
        }

        public async Task<ShowtimeEntity> GetWithMoviesByIdAsync(int id, CancellationToken cancel)
        {
            return await _showtimeRepository.GetWithMoviesByIdAsync(id, cancel);
        }

        public async Task<ShowtimeEntity> GetWithTicketsByIdAsync(int id, CancellationToken cancel)
        {
            return await _showtimeRepository.GetWithTicketsByIdAsync(id, cancel);
        }
    }
}
