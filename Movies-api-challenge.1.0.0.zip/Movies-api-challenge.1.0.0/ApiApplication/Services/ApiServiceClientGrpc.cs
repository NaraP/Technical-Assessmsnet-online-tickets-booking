﻿using ApiApplication.IServices;
using ApiApplication.Models;
using Grpc.Core;
using Grpc.Net.Client;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using ProtoDefinitions;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text.Json;
using System.Threading.Tasks;

namespace ApiApplication.Services
{
    public class ApiServiceClientGrpc : IApiServiceClientGrpc
    {
        private readonly ILogger<ApiServiceClientGrpc> _logger;
        private readonly IConfiguration _config;
        private readonly IRedisCacheService _redisCacheService;

        private const string cacheKey = "GrpcMovieList"; 

        public ApiServiceClientGrpc(
            IHttpClientFactory httpClientFactory,
            ILogger<ApiServiceClientGrpc> logger,
            IConfiguration config,
            IRedisCacheService redisCacheService)
        {
            _logger = logger;
            _config = config;
            _redisCacheService = redisCacheService;
        }

        public async Task<ShowListResponse> GetAllAsync()
        {
            // 1. Try to get the data from Redis cache
            var cachedMovies = await _redisCacheService.GetAsync(cacheKey);

            if (cachedMovies != null)
            {
                _logger.LogInformation("Returning data from Redis cache.");
                return cachedMovies;
            }

            // 2. Try from gRPC API

            try
            {
                var grpcUrl = _config["Grpc:MoviesUrl"] ?? "https://localhost:7443";
                var apiKey = _config["Grpc:ApiKey"] ?? throw new InvalidOperationException("API key is missing.");

                var handler = new HttpClientHandler
                {
                    ServerCertificateCustomValidationCallback = HttpClientHandler.DangerousAcceptAnyServerCertificateValidator
                };

                var channel = GrpcChannel.ForAddress(grpcUrl, new GrpcChannelOptions { HttpHandler = handler });
                var client = new MoviesApi.MoviesApiClient(channel);

                var headers = new Metadata { { "X-Apikey", apiKey } };
                var response = await client.GetAllAsync(new Empty(), new CallOptions(headers));

                if (response?.Success == true && response.Data.TryUnpack<showListResponse>(out var movieData))
                {
                    // Cache the result
                    await _redisCacheService.SetAsync(cacheKey, movieData, TimeSpan.FromMinutes(30));

                    // Convert the full movieData object to JSON string (if needed for logging or other purposes)
                    string json = JsonSerializer.Serialize(movieData, new JsonSerializerOptions
                    {
                        PropertyNamingPolicy = JsonNamingPolicy.CamelCase,
                        WriteIndented = false
                    });

                    var options = new JsonSerializerOptions
                    {
                        PropertyNameCaseInsensitive = true
                    };

                    var result = JsonSerializer.Deserialize<ShowListResponse>(json, options);

                    return result;
                }
            }
            catch (RpcException ex)
            {
                _logger.LogError(ex, "gRPC call failed: {Status} - {Detail}", ex.StatusCode, ex.Status.Detail);
            }
            catch (HttpRequestException ex)
            {
                _logger.LogError(ex, "HTTP error occurred while calling gRPC endpoint.");
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Unexpected error occurred in ApiServiceClientGrpc.");
            }

            // 3. Fallback: try to return stale cache if still null
            cachedMovies = await _redisCacheService.GetAsync(cacheKey);
            if (cachedMovies != null)
            {
                _logger.LogWarning("Returning stale cached data after API failure.");
            }

            return cachedMovies;
        }
    }
}
