﻿using System.Threading.Tasks;
using System;
using ApiApplication.Models;

namespace ApiApplication.IServices
{
    public interface IRedisCacheService
    {
        Task<ShowListResponse> GetAsync(string key);
        Task SetAsync<T>(string key, T value, TimeSpan? absoluteExpiration = null);
    }
}
