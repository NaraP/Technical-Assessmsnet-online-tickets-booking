﻿using ApiApplication.Database.Entities;
using ApiApplication.Models;
using System.Collections.Generic;
using System.Linq.Expressions;
using System.Threading.Tasks;
using System.Threading;
using System;

namespace ApiApplication.IServices
{
    public interface IShowtimeService
    {
        Task<ShowtimeEntity> CreateShowtime(ShowtimeRequest showtimeRequest, ShowListResponse movies, CancellationToken cancel);
        Task<IEnumerable<ShowtimeEntity>> GetAllAsync(Expression<Func<ShowtimeEntity, bool>> filter, CancellationToken cancel);
        Task<ShowtimeEntity> GetWithMoviesByIdAsync(int id, CancellationToken cancel);
        Task<ShowtimeEntity> GetWithTicketsByIdAsync(int id, CancellationToken cancel);
    }
}
