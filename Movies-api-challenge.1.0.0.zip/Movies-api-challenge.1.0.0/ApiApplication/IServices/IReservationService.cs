﻿using ApiApplication.Models;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Threading;
using System;

namespace ApiApplication.IServices
{
    public interface IReservationService
    {
        Task<ReservationResult> ReserveSeatsAsync(int showtimeId, IEnumerable<int> requestedSeatIds, CancellationToken cancel);
        Task<TicketConfirmationResult> ConfirmReservationAsync(Guid reservationId, CancellationToken cancellationToken);
    }
}
