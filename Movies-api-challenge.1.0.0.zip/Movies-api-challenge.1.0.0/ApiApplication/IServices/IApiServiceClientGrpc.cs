﻿using ApiApplication.Models;
using System.Threading.Tasks;

namespace ApiApplication.IServices
{
    public interface IApiServiceClientGrpc
    {
        Task<ShowListResponse> GetAllAsync();
    }
}
