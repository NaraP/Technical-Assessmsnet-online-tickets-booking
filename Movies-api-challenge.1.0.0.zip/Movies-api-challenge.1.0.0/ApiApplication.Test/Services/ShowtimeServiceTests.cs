﻿using ApiApplication.Database.Entities;
using ApiApplication.Database.Repositories.Abstractions;
using ApiApplication.IServices;
using ApiApplication.Models;
using ApiApplication.Services;
using FluentAssertions;
using Moq;
using System.Linq.Expressions;

namespace ApiApplication.Test.Services
{
    public class ShowtimeServiceTests
    {
        private readonly Mock<IShowtimesRepository> _mockShowtimeRepo;
        private readonly Mock<IApiServiceClientGrpc> _mockApiClient;
        private readonly ShowtimeService _service;

        public ShowtimeServiceTests()
        {
            _mockShowtimeRepo = new Mock<IShowtimesRepository>();
            _mockApiClient = new Mock<IApiServiceClientGrpc>();
            _service = new ShowtimeService(_mockShowtimeRepo.Object, _mockApiClient.Object);
        }

        [Fact]
        public async Task CreateShowtime_Should_Create_And_Return_Entity()
        {
            // Arrange
            var request = new ShowtimeRequest
            {
                Id = 1,
                AuditoriumId = 2,
                SessionDate = DateTime.UtcNow,
                Movie = new Movie
                {
                    Id = 123,
                    ReleaseDate = new DateTime(2022, 1, 1)
                },
                Tickets = new List<Ticket>()
            };

            var movieList = new ShowListResponse
            {
                Shows = new List<Show>
            {
                new Show
                {
                    Id = "tt12345",
                    Title = "Test Movie",
                    FullTitle = "Test Movie: Director's Cut",
                    ImDbRating = "8.2"
                }
            }
            };

            var expectedEntity = new ShowtimeEntity
            {
                Id = 1,
                AuditoriumId = 2,
                SessionDate = request.SessionDate,
                Movie = new MovieEntity
                {
                    Title = "Test Movie: Director's Cut"
                }
            };

            _mockShowtimeRepo
                .Setup(repo => repo.CreateShowtime(It.IsAny<ShowtimeEntity>(), It.IsAny<CancellationToken>()))
                .ReturnsAsync(expectedEntity);

            // Act
            var result = await _service.CreateShowtime(request, movieList, CancellationToken.None);

            // Assert
            result.Should().NotBeNull();
            result.Movie.Title.Should().Be("Test Movie: Director's Cut");
        }

        [Fact]
        public async Task GetWithMoviesByIdAsync_Should_Return_Entity()
        {
            var expected = new ShowtimeEntity { Id = 1 };

            _mockShowtimeRepo
                .Setup(repo => repo.GetWithMoviesByIdAsync(1, It.IsAny<CancellationToken>()))
                .ReturnsAsync(expected);

            var result = await _service.GetWithMoviesByIdAsync(1, CancellationToken.None);

            result.Should().BeEquivalentTo(expected);
        }

        [Fact]
        public async Task GetWithTicketsByIdAsync_Should_Return_Entity()
        {
            var expected = new ShowtimeEntity { Id = 2 };

            _mockShowtimeRepo
                .Setup(repo => repo.GetWithTicketsByIdAsync(2, It.IsAny<CancellationToken>()))
                .ReturnsAsync(expected);

            var result = await _service.GetWithTicketsByIdAsync(2, CancellationToken.None);

            result.Should().BeEquivalentTo(expected);
        }

        [Fact]
        public async Task GetAllAsync_Should_Return_Filtered_List()
        {
            var expectedList = new List<ShowtimeEntity>
        {
            new ShowtimeEntity { Id = 1 },
            new ShowtimeEntity { Id = 2 }
        };

            _mockShowtimeRepo
                .Setup(repo => repo.GetAllAsync(It.IsAny<Expression<Func<ShowtimeEntity, bool>>>(), It.IsAny<CancellationToken>()))
                .ReturnsAsync(expectedList);

            var result = await _service.GetAllAsync(x => x.Id > 0, CancellationToken.None);

            result.Should().HaveCount(2);
        }
    }
}
