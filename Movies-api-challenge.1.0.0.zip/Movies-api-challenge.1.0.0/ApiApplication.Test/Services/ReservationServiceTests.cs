﻿using ApiApplication.Database.Entities;
using ApiApplication.Database.Repositories.Abstractions;
using ApiApplication.Models;
using ApiApplication.Services;
using Microsoft.Extensions.Logging;
using Moq;

namespace ApiApplication.Test.Services
{
    public class ReservationServiceTests
    {
        private Mock<IShowtimesRepository> mockShowtimes;
        private Mock<IAuditoriumsRepository> mockAuditoriums;
        Mock<ITicketsRepository> mockTickets;

        public ReservationServiceTests()
        {
            mockShowtimes = new Mock<IShowtimesRepository>();
            mockAuditoriums = new Mock<IAuditoriumsRepository>();
            mockTickets = new Mock<ITicketsRepository>();
        }

        [Fact]
        public async Task ReserveSeatsAsync_NullSeatIds_ThrowsArgumentException()
        {
            // Arrange
            var service = new ReservationService(
                new Mock<ITicketsRepository>().Object,
                new Mock<IShowtimesRepository>().Object,
                new Mock<IAuditoriumsRepository>().Object,
                new Mock<ILogger<ReservationService>>().Object);

            // Act & Assert
            await Assert.ThrowsAsync<ArgumentException>(() =>
                service.ReserveSeatsAsync(1, null, CancellationToken.None));
        }

        [Fact]
        public async Task ReserveSeatsAsync_NonContiguousSeats_ThrowsInvalidOperationException()
        {
            // Arrange
            var seatIds = new List<int> { 1, 3 };

            var showtime = new ShowtimeEntity
            {
                Id = 1,
                AuditoriumId = 1,
                Movie = new MovieEntity { Title = "Dune" },
                Tickets = new List<TicketEntity>()
            };

            var auditorium = new AuditoriumEntity
            {
                Id = 1,
                Seats = new List<SeatEntity>
                            {
                                new SeatEntity { SeatNumber = 1, Row = 1 },
                                new SeatEntity { SeatNumber = 2, Row = 1 },
                                new SeatEntity { SeatNumber = 3, Row = 1 }
                            }
            };

            var showtimeRepo = new Mock<IShowtimesRepository>();
            showtimeRepo.Setup(x => x.GetWithTicketsByIdAsync(1, It.IsAny<CancellationToken>()))
                        .ReturnsAsync(showtime);

            var auditoriumRepo = new Mock<IAuditoriumsRepository>();
            auditoriumRepo.Setup(x => x.GetAsync(1, It.IsAny<CancellationToken>()))
                          .ReturnsAsync(auditorium);

            var service = new ReservationService(
                new Mock<ITicketsRepository>().Object,
                showtimeRepo.Object,
                auditoriumRepo.Object,
                new Mock<ILogger<ReservationService>>().Object);

            // Act & Assert
            await Assert.ThrowsAsync<InvalidOperationException>(() =>
                service.ReserveSeatsAsync(1, seatIds, CancellationToken.None));
        }

        [Fact]
        public async Task ReserveSeatsAsync_ValidRequest_ReturnsReservationResult()
        {
            // Arrange
            var showtimeId = 1;
            var seatIds = new List<int> { 1, 2 };

            var showtime = new ShowtimeEntity
            {
                Id = showtimeId,
                AuditoriumId = 100,
                Movie = new MovieEntity { Title = "Interstellar" },
                Tickets = new List<TicketEntity>()
            };

            var auditorium = new AuditoriumEntity
            {
                Id = 100,
                Seats = new List<SeatEntity>
        {
            new SeatEntity { SeatNumber = 1, Row = 1 },
            new SeatEntity { SeatNumber = 2, Row = 1 },
            new SeatEntity { SeatNumber = 3, Row = 1 }
        }
            };

            var mockShowtimes = new Mock<IShowtimesRepository>();
            mockShowtimes.Setup(x => x.GetWithTicketsByIdAsync(showtimeId, It.IsAny<CancellationToken>()))
                         .ReturnsAsync(showtime);

            var mockAuditoriums = new Mock<IAuditoriumsRepository>();
            mockAuditoriums.Setup(x => x.GetAsync(showtime.AuditoriumId, It.IsAny<CancellationToken>()))
                           .ReturnsAsync(auditorium);

            var mockTickets = new Mock<ITicketsRepository>();
            mockTickets.Setup(x => x.CreateAsync(It.IsAny<ShowtimeEntity>(), It.IsAny<List<SeatEntity>>(), It.IsAny<CancellationToken>()))
                       .ReturnsAsync(new TicketEntity { Id = Guid.NewGuid(), Seats = new List<SeatEntity>(), ShowtimeId = showtimeId });

            var logger = new Mock<ILogger<ReservationService>>();

            var service = new ReservationService(mockTickets.Object, mockShowtimes.Object, mockAuditoriums.Object, logger.Object);

            // Act
            var result = await service.ReserveSeatsAsync(showtimeId, seatIds, CancellationToken.None);

            // Assert
            Assert.Equal(2, result.SeatCount);
            Assert.Equal("Interstellar", result.MovieTitle);
            Assert.Equal(100, result.AuditoriumId);
        }
    }
}
