﻿using ApiApplication.Database.Repositories;
using ApiApplication.Database;
using Microsoft.EntityFrameworkCore;
using ApiApplication.Database.Entities;
using Moq;
using System.Linq.Expressions;

namespace ApiApplication.Test.Repository
{
    public class ShowtimesRepositoryTests
    {
        private readonly DbContextOptions<CinemaContext> _dbOptions;
        private readonly CinemaContext _context;
        private readonly ShowtimesRepository _repository;

        public ShowtimesRepositoryTests()
        {
            // Setup in-memory database
            _dbOptions = new DbContextOptionsBuilder<CinemaContext>()
                .UseInMemoryDatabase(databaseName: Guid.NewGuid().ToString()) // Unique DB per test
                .Options;
            _context = new CinemaContext(_dbOptions);
            _repository = new ShowtimesRepository(_context);
        }

        private async Task SeedDataAsync()
        {
            // Seed test data
            var movie = new MovieEntity { Id = 1, Title = "Test Movie" };
            var showtime = new ShowtimeEntity
            {
                Id = 1,
                AuditoriumId = 1,
                Movie = movie,
                Tickets = new List<TicketEntity>
            {
                new TicketEntity { Id = Guid.NewGuid(), ShowtimeId = 1, Paid = false, CreatedTime = DateTime.UtcNow }
            }
            };

            await _context.Movies.AddAsync(movie);
            await _context.Showtimes.AddAsync(showtime);
            await _context.SaveChangesAsync();
        }

        [Fact]
        public async Task GetWithMoviesByIdAsync_ReturnsShowtimeWithMovie_WhenShowtimeExists()
        {
            // Arrange
            await SeedDataAsync();
            var showtimeId = 1;
            var cancellationToken = CancellationToken.None;

            // Act
            var result = await _repository.GetWithMoviesByIdAsync(showtimeId, cancellationToken);

            // Assert
            Assert.NotNull(result);
            Assert.Equal(showtimeId, result.Id);
            Assert.NotNull(result.Movie);
            Assert.Equal("Test Movie", result.Movie.Title);
        }

        [Fact]
        public async Task GetWithMoviesByIdAsync_ReturnsNull_WhenShowtimeDoesNotExist()
        {
            // Arrange
            var showtimeId = 999;
            var cancellationToken = CancellationToken.None;

            // Act
            var result = await _repository.GetWithMoviesByIdAsync(showtimeId, cancellationToken);

            // Assert
            Assert.Null(result);
        }

        [Fact]
        public async Task GetWithMoviesByIdAsync_ThrowsOperationCanceled_WhenCancellationRequested()
        {
            // Arrange
            var showtimeId = 1;
            var cts = new CancellationTokenSource();
            cts.Cancel();

            // Act & Assert
            await Assert.ThrowsAsync<OperationCanceledException>(() =>
                _repository.GetWithMoviesByIdAsync(showtimeId, cts.Token));
        }

        [Fact]
        public async Task GetWithTicketsByIdAsync_ReturnsShowtimeWithTickets_WhenShowtimeExists()
        {
            // Arrange
            await SeedDataAsync();
            var showtimeId = 1;
            var cancellationToken = CancellationToken.None;

            // Act
            var result = await _repository.GetWithTicketsByIdAsync(showtimeId, cancellationToken);

            // Assert
            Assert.NotNull(result);
            Assert.Equal(showtimeId, result.Id);
            Assert.Single(result.Tickets);
            Assert.False(result.Tickets.First().Paid);
        }

        [Fact]
        public async Task GetWithTicketsByIdAsync_ReturnsNull_WhenShowtimeDoesNotExist()
        {
            // Arrange
            var showtimeId = 999;
            var cancellationToken = CancellationToken.None;

            // Act
            var result = await _repository.GetWithTicketsByIdAsync(showtimeId, cancellationToken);

            // Assert
            Assert.Null(result);
        }

        [Fact]
        public async Task GetWithTicketsByIdAsync_ThrowsOperationCanceled_WhenCancellationRequested()
        {
            // Arrange
            var showtimeId = 1;
            var cts = new CancellationTokenSource();
            cts.Cancel();

            // Act & Assert
            await Assert.ThrowsAsync<OperationCanceledException>(() =>
                _repository.GetWithTicketsByIdAsync(showtimeId, cts.Token));
        }

        [Fact]
        public async Task GetAllAsync_ReturnsAllShowtimes_WhenFilterIsNull()
        {
            // Arrange
            await SeedDataAsync();
            Expression<Func<ShowtimeEntity, bool>>? filter = null;
            var cancellationToken = CancellationToken.None;

            // Act
            var result = await _repository.GetAllAsync(filter, cancellationToken);

            // Assert
            Assert.Single(result);
            var showtime = result.First();
            Assert.Equal(1, showtime.Id);
            Assert.NotNull(showtime.Movie);
            Assert.Equal("Test Movie", showtime.Movie.Title);
        }

        [Fact]
        public async Task GetAllAsync_ReturnsFilteredShowtimes_WhenFilterIsProvided()
        {
            // Arrange
            await SeedDataAsync();
            Expression<Func<ShowtimeEntity, bool>> filter = s => s.Movie.Id == 1;
            var cancellationToken = CancellationToken.None;

            // Act
            var result = await _repository.GetAllAsync(filter, cancellationToken);

            // Assert
            Assert.Single(result);
            Assert.Equal(1, result.First().Movie.Id);
        }

        [Fact]
        public async Task GetAllAsync_ReturnsEmpty_WhenNoShowtimesMatchFilter()
        {
            // Arrange
            await SeedDataAsync();
            Expression<Func<ShowtimeEntity, bool>> filter = s => s.Movie.Id == 999;
            var cancellationToken = CancellationToken.None;

            // Act
            var result = await _repository.GetAllAsync(filter, cancellationToken);

            // Assert
            Assert.Empty(result);
        }

        [Fact]
        public async Task GetAllAsync_ThrowsOperationCanceled_WhenCancellationRequested()
        {
            // Arrange
            Expression<Func<ShowtimeEntity, bool>>? filter = null;
            var cts = new CancellationTokenSource();
            cts.Cancel();

            // Act & Assert
            await Assert.ThrowsAsync<OperationCanceledException>(() =>
                _repository.GetAllAsync(filter, cts.Token));
        }

        [Fact]
        public async Task CreateShowtime_CreatesNewShowtime_WhenNoDuplicateExists()
        {
            // Arrange
            var newShowtime = new ShowtimeEntity
            {
                Id = 2,
                AuditoriumId = 2,
                Movie = new MovieEntity { Id = 2, Title = "New Movie" }
            };
            var cancellationToken = CancellationToken.None;

            // Act
            var result = await _repository.CreateShowtime(newShowtime, cancellationToken);

            // Assert
            Assert.NotNull(result);
            Assert.Equal(2, result.Id);
            Assert.Equal("New Movie", result.Movie.Title);
            var savedShowtime = await _context.Showtimes.FindAsync(new object[] { 2 }, cancellationToken);
            Assert.NotNull(savedShowtime);
        }

        [Fact]
        public async Task CreateShowtime_ReturnsExistingShowtime_WhenDuplicateExists()
        {
            // Arrange
            await SeedDataAsync();
            var duplicateShowtime = new ShowtimeEntity
            {
                Id = 1,
                AuditoriumId = 1,
                Movie = new MovieEntity { Id = 1, Title = "Test Movie" }
            };
            var cancellationToken = CancellationToken.None;

            // Act
            var result = await _repository.CreateShowtime(duplicateShowtime, cancellationToken);

            // Assert
            Assert.NotNull(result);
            Assert.Equal(1, result.Id);
            Assert.Equal("Test Movie", result.Movie.Title);
            Assert.Single(_context.Showtimes); // No new showtime added
        }

        [Fact]
        public async Task CreateShowtime_HandlesDbException_AndReturnsEntity()
        {
            // Arrange
            var mockContext = new Mock<CinemaContext>(_dbOptions);
            var mockShowtimes = new Mock<DbSet<ShowtimeEntity>>();
            mockShowtimes.Setup(m => m.AddAsync(It.IsAny<ShowtimeEntity>(), It.IsAny<CancellationToken>()))
                .ThrowsAsync(new DbUpdateException("Database error", new Exception()));

            var movie = new MovieEntity();

            Expression<Func<ShowtimeEntity, bool>> filter = showtime =>
                           showtime.Movie == movie &&
                           showtime.Movie == movie &&
                           showtime.Id == 1;

            CancellationToken cancellationToken1 = CancellationToken.None;

            var repository = new ShowtimesRepository(mockContext.Object);

            var results = repository.GetAllAsync(filter, cancellationToken1);


            var newShowtime = new ShowtimeEntity
            {
                Id = 3,
                AuditoriumId = 3,
                Movie = new MovieEntity
                {
                    Id = 3,
                    Title = "Error Movie"
                },
                Tickets = new List<TicketEntity>
    {
                new TicketEntity
                {
                    Id = Guid.NewGuid(),
                    CreatedTime = DateTime.UtcNow,
                    Seats = new List<SeatEntity>
                    {
                        new SeatEntity
                        {
                            AuditoriumId = 3
                        }
                    }
                }
            }
          };

            var cancellationToken = CancellationToken.None;

            // Act
            var result = await repository.CreateShowtime(newShowtime, cancellationToken);

            // Assert
            Assert.NotNull(result);
            Assert.Equal(3, result.Id);
            Assert.Equal("Error Movie", result.Movie.Title);
        }

        [Fact]
        public async Task CreateShowtime_ThrowsOperationCanceled_WhenCancellationRequested()
        {
            // Arrange
            var newShowtime = new ShowtimeEntity
            {
                Id = 2,
                AuditoriumId = 2,
                Movie = new MovieEntity { Id = 2, Title = "New Movie" }
            };
            var cts = new CancellationTokenSource();
            cts.Cancel();

            // Act & Assert
            await Assert.ThrowsAsync<OperationCanceledException>(() =>
                _repository.CreateShowtime(newShowtime, cts.Token));
        }

        public void Dispose()
        {
            _context.Database.EnsureDeleted();
            _context.Dispose();
        }
    }

}
