﻿using ApiApplication.Controllers;
using ApiApplication.Database.Entities;
using ApiApplication.IServices;
using ApiApplication.Models;
using FluentAssertions;
using Microsoft.AspNetCore.Mvc;
using Moq;

namespace ApiApplication.Test.Controllers
{
    public class ShowtimeControllerTests
    {
        private readonly Mock<IShowtimeService> _mockShowtimeService;
        private readonly Mock<IApiServiceClientGrpc> _mockApiServiceClient;
        private readonly ShowtimeController _controller;

        public ShowtimeControllerTests()
        {
            _mockShowtimeService = new Mock<IShowtimeService>();
            _mockApiServiceClient = new Mock<IApiServiceClientGrpc>();
            _controller = new ShowtimeController(_mockShowtimeService.Object, _mockApiServiceClient.Object);
        }

        [Fact]
        public async Task CreateShowtime_Should_Return_BadRequest_When_Request_Is_Null()
        {
            // Act
            var result = await _controller.CreateShowtime(null, CancellationToken.None);

            // Assert
            result.Should().BeOfType<BadRequestObjectResult>();
        }

        [Fact]
        public async Task CreateShowtime_Should_Return_BadRequest_When_Movie_Is_Null()
        {
            var request = new ShowtimeRequest { Movie = null };

            var result = await _controller.CreateShowtime(request, CancellationToken.None);

            result.Should().BeOfType<BadRequestObjectResult>();
        }

        [Fact]
        public async Task CreateShowtime_Should_Return_Ok_When_Valid()
        {
            var request = new ShowtimeRequest { Movie = new Movie() };

            var movieList = new ShowListResponse
            {
                Shows = new List<Show> { new Show { Title = "Test movie" } }
            };

            var showtimeResponse = new ShowtimeEntity { Id = 1 };

            _mockApiServiceClient.Setup(x => x.GetAllAsync()).ReturnsAsync(movieList);
            _mockShowtimeService.Setup(x => x.CreateShowtime(request, movieList, It.IsAny<CancellationToken>()))
                .ReturnsAsync(showtimeResponse);

            var result = await _controller.CreateShowtime(request, CancellationToken.None);

            result.Should().BeOfType<OkObjectResult>()
                .Which.Value.Should().BeEquivalentTo(showtimeResponse);
        }


        [Fact]
        public async Task GetShowtime_Should_Return_Ok_When_Found()
        {
            var expected = new ShowtimeEntity { Id = 1 };
            _mockShowtimeService.Setup(x => x.GetWithMoviesByIdAsync(1, It.IsAny<CancellationToken>()))
                .ReturnsAsync(expected);

            var result = await _controller.GetShowtime(1, CancellationToken.None);

            result.Should().BeOfType<OkObjectResult>()
                .Which.Value.Should().BeEquivalentTo(expected);
        }
    }

}
