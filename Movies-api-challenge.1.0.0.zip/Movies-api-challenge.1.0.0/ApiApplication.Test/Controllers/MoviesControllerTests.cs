﻿using ApiApplication.Controllers;
using ApiApplication.IServices;
using ApiApplication.Models;
using Microsoft.AspNetCore.Mvc;
using Moq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ApiApplication.Test.Controllers
{
    public class MoviesControllerTests
    {
        private readonly Mock<IApiServiceClientGrpc> _mockApiServiceClientGrpc;
        private readonly MoviesController _controller;
        public MoviesControllerTests()
        {
            _mockApiServiceClientGrpc = new Mock<IApiServiceClientGrpc>();
            _controller = new MoviesController(_mockApiServiceClientGrpc.Object);
        }

        [Fact]
        public async Task GetMovies_ReturnsOk_WithMovies_WhenServiceReturnsMovies()
        {
            // Arrange
            // Arrange
            var movies = new ShowListResponse
            {
                        Shows = new List<Show>
                        {
                            new Show { Id = "1", Title = "Interstellar", Rank = "1" },
                            new Show { Id = "2", Title = "Inception", Rank = "2" }
                        }
            };

            _mockApiServiceClientGrpc
                .Setup(s => s.GetAllAsync())
                .ReturnsAsync(movies);

            // Act
            var actionResult = await _controller.GetMovies();

            // Assert
            var okResult = Assert.IsType<OkObjectResult>(actionResult);
            Assert.Equal(200, okResult.StatusCode);
            Assert.Equal(movies, okResult.Value);
            _mockApiServiceClientGrpc.Verify(s => s.GetAllAsync(), Times.Once());
        }
    }
}
