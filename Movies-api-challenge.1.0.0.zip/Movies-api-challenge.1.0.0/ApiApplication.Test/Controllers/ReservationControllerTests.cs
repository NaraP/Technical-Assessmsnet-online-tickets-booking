﻿using ApiApplication.Controllers;
using ApiApplication.IServices;
using ApiApplication.Models;
using Microsoft.AspNetCore.Mvc;
using Moq;

namespace ApiApplication.Test.Controllers
{
    public class ReservationControllerTests
    {
        Mock<IReservationService> mockService;

        public ReservationControllerTests()
        {
            mockService = new Mock<IReservationService>();
        }

        [Fact]
        public async Task ConfirmReservation_ReturnsOk_WhenSuccess()
        {
            // Arrange
            var reservationId = Guid.NewGuid();

            mockService.Setup(s => s.ConfirmReservationAsync(reservationId, It.IsAny<CancellationToken>()))
                       .ReturnsAsync(TicketConfirmationResult.Success);

            var controller = new ReservationController(mockService.Object);

            // Act
            var result = await controller.ConfirmReservation(reservationId, CancellationToken.None);

            // Assert
            var okResult = Assert.IsType<OkObjectResult>(result);
            Assert.Equal("Reservation confirmed.", okResult.Value);
        }

        [Fact]
        public async Task ReserveSeats_ReturnsBadRequest_OnError() 
        {
            // Arrange
            var mockService = new Mock<IReservationService>();
            var request = new ReserveSeatsRequest { ShowtimeId = 1, SeatIds = new List<int> { 1 } };

            mockService.Setup(s => s.ReserveSeatsAsync(It.IsAny<int>(), It.IsAny<IEnumerable<int>>(), It.IsAny<CancellationToken>()))
                       .ThrowsAsync(new Exception("Some error"));

            var controller = new ReservationController(mockService.Object);

            // Act
            var result = await controller.ReserveSeats(request, CancellationToken.None);

            // Assert
            var badResult = Assert.IsType<BadRequestObjectResult>(result);
            Assert.Contains("Some error", badResult.Value.ToString());
        }
    }
}
